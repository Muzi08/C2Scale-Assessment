install dependencies - npm install

start dev server - npm run dev
start BE server - cd ./server --> node index.js

IMPORTANT - For the live url i have used Render for deploying BE with free plan, so they stops the server due to inactivity and it takes around 5 minutes for it to start again. please bear with this. Or you can run BE locally change the URL to "http://localhost:5000" in /pages/home  

i have delayed responses from server to test the loading UI.

I have used shadcn library for ui components and choosed apple theme for the UI 
